using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;

public class ButtonControl : MonoBehaviour
{
    public GameObject pausePanel;

    public GameObject settingsPanel;
    public GameObject MainPanel;
    public void PlayButton()
    {
        SceneManager.LoadScene("GameScene");
    }
    public void ExitButton()
    {
        Application.Quit();
    }

    public void BackButton()
    {
        SceneManager.LoadScene("Menu");
    }
    public void PauseButonu()
    {
        pausePanel.SetActive(true);
        Time.timeScale = 0f; // Oyun zaman�n� durdur
    }
    public void ResumeButonu()
    {
        pausePanel.SetActive(false);
        Time.timeScale = 1f; // Oyun zaman�n� normale �evir
    }

    public void AyarlarButonu()
    {
        MainPanel.SetActive(false);
        settingsPanel.SetActive(true);
    }

    public void MenuyeDon()
    {
        MainPanel.SetActive(true); // Main
        settingsPanel.SetActive(false); // 
    }
    public void Sifirla()
    {
        // Oyun ilerlemesini s�f�rlamak i�in 
        PlayerPrefs.DeleteAll(); 
    }
}
